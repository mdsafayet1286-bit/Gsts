package com.drdecay.welkinmoon;

import java.util.Optional;
import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.block.*;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;

public final class ModBlocks2 {
    public static final Block MOONSTONE_ORE = reg("moonstone_ore", new Block(AbstractBlock.Settings.copy(Blocks.DIAMOND_ORE)));
    public static final Block DEEPSLATE_MOONSTONE_ORE = reg("deepslate_moonstone_ore", new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_DIAMOND_ORE)));
    public static final Block MOONSTONE_BLOCK = reg("moonstone_block", new Block(AbstractBlock.Settings.copy(Blocks.IRON_BLOCK).luminance(s -> 6)));

    public static final Block DREAD_LOG = reg("dread_log", new PillarBlock(AbstractBlock.Settings.copy(Blocks.OAK_LOG)));
    public static final Block STRIPPED_DREAD_LOG = reg("stripped_dread_log", new PillarBlock(AbstractBlock.Settings.copy(Blocks.STRIPPED_OAK_LOG)));
    public static final Block DREAD_WOOD = reg("dread_wood", new PillarBlock(AbstractBlock.Settings.copy(Blocks.OAK_WOOD)));
    public static final Block STRIPPED_DREAD_WOOD = reg("stripped_dread_wood", new PillarBlock(AbstractBlock.Settings.copy(Blocks.STRIPPED_OAK_WOOD)));
    public static final Block DREAD_PLANKS = reg("dread_planks", new Block(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS)));
    public static final Block DREAD_STAIRS = reg("dread_stairs", new StairsBlock(DREAD_PLANKS.getDefaultState(), AbstractBlock.Settings.copy(Blocks.OAK_STAIRS)));
    public static final Block DREAD_SLAB = reg("dread_slab", new SlabBlock(AbstractBlock.Settings.copy(Blocks.OAK_SLAB)));
    public static final Block DREAD_LEAVES = reg("dread_leaves", new LeavesBlock(AbstractBlock.Settings.copy(Blocks.OAK_LEAVES)));
    public static final SaplingGenerator DREAD_TREE = new SaplingGenerator("dread", Optional.of(RegistryKey.of(RegistryKeys.CONFIGURED_FEATURE, WelkinMoon.id("dread_massive_tree"))), Optional.of(RegistryKey.of(RegistryKeys.CONFIGURED_FEATURE, WelkinMoon.id("dread_tree"))), Optional.empty());
    public static final Block DREAD_SAPLING = reg("dread_sapling", new SaplingBlock(DREAD_TREE, AbstractBlock.Settings.copy(Blocks.OAK_SAPLING)));

    public static final Block ASHEN_LOG = reg("ashen_log", new PillarBlock(AbstractBlock.Settings.copy(Blocks.OAK_LOG)));
    public static final Block STRIPPED_ASHEN_LOG = reg("stripped_ashen_log", new PillarBlock(AbstractBlock.Settings.copy(Blocks.STRIPPED_OAK_LOG)));
    public static final Block ASHEN_WOOD = reg("ashen_wood", new PillarBlock(AbstractBlock.Settings.copy(Blocks.OAK_WOOD)));
    public static final Block STRIPPED_ASHEN_WOOD = reg("stripped_ashen_wood", new PillarBlock(AbstractBlock.Settings.copy(Blocks.STRIPPED_OAK_WOOD)));
    public static final Block ASHEN_PLANKS = reg("ashen_planks", new Block(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS)));
    public static final Block ASHEN_STAIRS = reg("ashen_stairs", new StairsBlock(ASHEN_PLANKS.getDefaultState(), AbstractBlock.Settings.copy(Blocks.OAK_STAIRS)));
    public static final Block ASHEN_SLAB = reg("ashen_slab", new SlabBlock(AbstractBlock.Settings.copy(Blocks.OAK_SLAB)));
    public static final Block ASHEN_LEAVES = reg("ashen_leaves", new LeavesBlock(AbstractBlock.Settings.copy(Blocks.OAK_LEAVES)));
    public static final SaplingGenerator ASHEN_TREE = new SaplingGenerator("ashen", Optional.empty(), Optional.of(RegistryKey.of(RegistryKeys.CONFIGURED_FEATURE, WelkinMoon.id("ashen_tree"))), Optional.empty());
    public static final Block ASHEN_SAPLING = reg("ashen_sapling", new SaplingBlock(ASHEN_TREE, AbstractBlock.Settings.copy(Blocks.OAK_SAPLING)));

    private static <T extends Block> T reg(String name, T block) {
        Registry.register(Registries.BLOCK, WelkinMoon.id(name), block);
        BlockItem item = Registry.register(Registries.ITEM, WelkinMoon.id(name), new BlockItem(block, new Item.Settings()));
        ModItems.ALL.add(item);
        return block;
    }

    public static void init() {
        StrippableBlockRegistry.register(DREAD_LOG, STRIPPED_DREAD_LOG);
        StrippableBlockRegistry.register(DREAD_WOOD, STRIPPED_DREAD_WOOD);
        StrippableBlockRegistry.register(ASHEN_LOG, STRIPPED_ASHEN_LOG);
        StrippableBlockRegistry.register(ASHEN_WOOD, STRIPPED_ASHEN_WOOD);
        FlammableBlockRegistry f = FlammableBlockRegistry.getDefaultInstance();
        for (Block b : new Block[]{DREAD_LOG, STRIPPED_DREAD_LOG, DREAD_WOOD, STRIPPED_DREAD_WOOD, ASHEN_LOG, STRIPPED_ASHEN_LOG, ASHEN_WOOD, STRIPPED_ASHEN_WOOD}) f.add(b, 5, 5);
        for (Block b : new Block[]{DREAD_PLANKS, DREAD_STAIRS, DREAD_SLAB, ASHEN_PLANKS, ASHEN_STAIRS, ASHEN_SLAB}) f.add(b, 5, 20);
        f.add(DREAD_LEAVES, 30, 60); f.add(ASHEN_LEAVES, 30, 60);
    }
}
