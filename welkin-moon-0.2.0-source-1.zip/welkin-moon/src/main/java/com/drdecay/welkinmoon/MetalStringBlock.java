package com.drdecay.welkinmoon;

import net.minecraft.block.*;
import java.util.Optional;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.CampfireCookingRecipe;
import net.minecraft.recipe.RecipeEntry;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.input.SingleStackRecipeInput;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.ItemActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.IntProperty;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.random.Random;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;
import net.minecraft.world.WorldView;

/** Wire placed on the ground. Between two powered redstone sources it heats up (heat 0-3). */
public class MetalStringBlock extends Block {
    public static final IntProperty HEAT = IntProperty.of("heat", 0, 3);
    private static final VoxelShape SHAPE = Block.createCuboidShape(0, 0, 0, 16, 1, 16);

    public MetalStringBlock(Settings settings) {
        super(settings);
        setDefaultState(getStateManager().getDefaultState().with(HEAT, 0));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> b) { b.add(HEAT); }

    @Override
    protected VoxelShape getOutlineShape(BlockState s, BlockView w, BlockPos p, ShapeContext c) { return SHAPE; }

    @Override
    protected VoxelShape getCollisionShape(BlockState s, BlockView w, BlockPos p, ShapeContext c) { return VoxelShapes.empty(); }

    @Override
    protected boolean canPlaceAt(BlockState state, WorldView world, BlockPos pos) {
        return Block.sideCoversSmallSquare(world, pos.down(), Direction.UP);
    }

    @Override
    protected BlockState getStateForNeighborUpdate(BlockState state, Direction dir, BlockState nState, WorldAccess world, BlockPos pos, BlockPos nPos) {
        return state.canPlaceAt(world, pos) ? state : Blocks.AIR.getDefaultState();
    }

    @Override
    protected void onBlockAdded(BlockState state, World world, BlockPos pos, BlockState old, boolean moved) {
        world.scheduleBlockTick(pos, this, 20);
    }

    @Override
    protected void neighborUpdate(BlockState state, World world, BlockPos pos, Block source, BlockPos sourcePos, boolean notify) {
        world.scheduleBlockTick(pos, this, 20);
    }

    private static boolean powerAt(World world, BlockPos pos, Direction d) {
        BlockPos n = pos.offset(d);
        BlockState s = world.getBlockState(n);
        if (s.isOf(Blocks.REDSTONE_WIRE)) return s.get(RedstoneWireBlock.POWER) > 0;
        return world.getEmittedRedstonePower(n, d) > 0;
    }

    private static boolean live(World world, BlockPos pos, Direction a, Direction b) {
        return powerAt(world, pos, a) && powerAt(world, pos, b);
    }

    @Override
    protected void scheduledTick(BlockState state, ServerWorld world, BlockPos pos, Random random) {
        boolean live = live(world, pos, Direction.EAST, Direction.WEST) || live(world, pos, Direction.NORTH, Direction.SOUTH);
        int heat = state.get(HEAT);
        int next = live ? Math.min(3, heat + 1) : Math.max(0, heat - 1);
        if (next != heat) world.setBlockState(pos, state.with(HEAT, next), Block.NOTIFY_ALL);
        if (next >= 2) {
            for (BlockPos p : BlockPos.iterate(pos.add(-1, -1, -1), pos.add(1, 1, 1))) {
                BlockState s = world.getBlockState(p);
                if (s.isOf(Blocks.ICE)) world.setBlockState(p.toImmutable(), Blocks.WATER.getDefaultState());
                else if (s.isOf(Blocks.SNOW)) world.removeBlock(p.toImmutable(), false);
            }
        }
        if (next == 3 && random.nextInt(4) == 0) {
            BlockPos up = pos.up();
            if (world.isAir(up)) world.setBlockState(up, AbstractFireBlock.getState(world, up));
        }
        if (live || next > 0) world.scheduleBlockTick(pos, this, 100);
    }

    @Override
    protected ItemActionResult onUseWithItem(ItemStack stack, BlockState state, World world, BlockPos pos, PlayerEntity player, Hand hand, BlockHitResult hit) {
        if (state.get(HEAT) < 2 || stack.isEmpty()) return ItemActionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        SingleStackRecipeInput input = new SingleStackRecipeInput(stack);
        Optional<RecipeEntry<CampfireCookingRecipe>> r = world.getRecipeManager().getFirstMatch(RecipeType.CAMPFIRE_COOKING, input, world);
        if (r.isEmpty()) return ItemActionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        if (!world.isClient) {
            ItemStack out = r.get().value().craft(input, world.getRegistryManager());
            if (!player.getAbilities().creativeMode) stack.decrement(1);
            Block.dropStack(world, pos.up(), out);
            world.playSound(null, pos, SoundEvents.BLOCK_CAMPFIRE_CRACKLE, SoundCategory.BLOCKS, 1f, 1f);
        }
        return ItemActionResult.success(world.isClient);
    }

    @Override
    protected void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
        int heat = state.get(HEAT);
        if (!world.isClient && heat >= 2 && entity instanceof LivingEntity && !entity.isFireImmune()) {
            entity.damage(world.getDamageSources().hotFloor(), 1.0f);
            if (heat == 3) entity.setOnFireFor(4);
        }
    }
}
