package com.drdecay.welkinmoon;

import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;

public final class ModEffects {
    public static final RegistryEntry<StatusEffect> SOURNESS =
        Registry.registerReference(Registries.STATUS_EFFECT, WelkinMoon.id("sourness"), new SournessEffect());

    public static void init() {}
}
