package com.drdecay.welkinmoon;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.World;

public class ConstructorZombieEntity extends ZombieEntity {
    public ConstructorZombieEntity(EntityType<? extends ZombieEntity> type, World world) { super(type, world); }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return ZombieEntity.createZombieAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 32.0).add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 5.0);
    }

    @Override
    protected void initEquipment(Random random, LocalDifficulty difficulty) {
        equipStack(EquipmentSlot.MAINHAND, new ItemStack(random.nextInt(4) == 0 ? ModItems2.CEMENT_HAMMER : ModItems2.TIN_PICKAXE));
        equipStack(EquipmentSlot.HEAD, new ItemStack(Items.GOLDEN_HELMET));
    }
}
