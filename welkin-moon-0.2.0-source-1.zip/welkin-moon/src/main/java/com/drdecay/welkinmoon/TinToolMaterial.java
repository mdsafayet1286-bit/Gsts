package com.drdecay.welkinmoon;

import net.minecraft.block.Block;
import net.minecraft.item.ToolMaterial;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.TagKey;

public enum TinToolMaterial implements ToolMaterial {
    INSTANCE;
    @Override public int getDurability() { return 190; }
    @Override public float getMiningSpeedMultiplier() { return 5.5f; }
    @Override public float getAttackDamage() { return 1.5f; }
    @Override public TagKey<Block> getInverseTag() { return BlockTags.INCORRECT_FOR_STONE_TOOL; }
    @Override public int getEnchantability() { return 14; }
    @Override public Ingredient getRepairIngredient() { return Ingredient.ofItems(ModItems.TIN_INGOT); }
}
