package com.drdecay.welkinmoon;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.projectile.thrown.ThrownItemEntity;
import net.minecraft.item.Item;
import net.minecraft.particle.DustParticleEffect;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.world.World;
import org.joml.Vector3f;

public class ThrownBagEntity extends ThrownItemEntity {
    public ThrownBagEntity(EntityType<? extends ThrownBagEntity> type, World world) { super(type, world); }
    public ThrownBagEntity(World world, LivingEntity owner) { super(ModEntities.THROWN_BAG, owner, world); }

    @Override protected Item getDefaultItem() { return ModBlocks.BAG_OF_CEMENT.asItem(); }

    @Override
    protected void onEntityHit(EntityHitResult result) {
        super.onEntityHit(result);
        result.getEntity().damage(getDamageSources().thrown(this, getOwner()), 4.0f);
    }

    @Override
    protected void onCollision(HitResult hit) {
        super.onCollision(hit);
        if (!getWorld().isClient) {
            ServerWorld sw = (ServerWorld) getWorld();
            sw.spawnParticles(new DustParticleEffect(new Vector3f(0.78f, 0.78f, 0.80f), 3.0f), getX(), getY(), getZ(), 90, 1.3, 0.8, 1.3, 0.02);
            sw.playSound(null, getBlockPos(), SoundEvents.BLOCK_WOOL_BREAK, SoundCategory.NEUTRAL, 1.0f, 0.7f);
            for (LivingEntity e : sw.getEntitiesByClass(LivingEntity.class, getBoundingBox().expand(3.0), x -> true)) {
                e.addStatusEffect(new StatusEffectInstance(StatusEffects.BLINDNESS, 60, 0));
                e.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 60, 1));
            }
            discard();
        }
    }
}
