package com.drdecay.welkinmoon;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.ZombieEntityRenderer;
import net.minecraft.entity.mob.ZombieEntity;
import net.minecraft.util.Identifier;

public class ConstructorZombieRenderer extends ZombieEntityRenderer {
    private static final Identifier TEXTURE = WelkinMoon.id("textures/entity/constructor_zombie.png");
    public ConstructorZombieRenderer(EntityRendererFactory.Context ctx) { super(ctx); }
    @Override public Identifier getTexture(ZombieEntity entity) { return TEXTURE; }
}
