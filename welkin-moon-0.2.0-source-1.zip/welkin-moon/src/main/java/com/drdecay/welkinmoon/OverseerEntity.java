package com.drdecay.welkinmoon;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.ai.goal.*;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.entity.boss.ServerBossBar;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.mob.SilverfishEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.world.World;

/** Stronghold boss. Ground-slams, applies Sourness, and summons silverfish below half health. */
public class OverseerEntity extends HostileEntity {
    private final ServerBossBar bossBar = new ServerBossBar(Text.literal("Stronghold Overseer"), BossBar.Color.RED, BossBar.Style.NOTCHED_10);
    private int slamCooldown = 120;

    public OverseerEntity(EntityType<? extends OverseerEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 150;
    }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return HostileEntity.createHostileAttributes()
            .add(EntityAttributes.GENERIC_MAX_HEALTH, 300.0)
            .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28)
            .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 14.0)
            .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 40.0)
            .add(EntityAttributes.GENERIC_KNOCKBACK_RESISTANCE, 1.0)
            .add(EntityAttributes.GENERIC_ARMOR, 10.0);
    }

    @Override
    protected void initGoals() {
        goalSelector.add(0, new SwimGoal(this));
        goalSelector.add(1, new MeleeAttackGoal(this, 1.0, false));
        goalSelector.add(2, new WanderAroundFarGoal(this, 0.6));
        goalSelector.add(3, new LookAtEntityGoal(this, PlayerEntity.class, 16.0f));
        goalSelector.add(4, new LookAroundGoal(this));
        targetSelector.add(1, new RevengeGoal(this));
        targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public void onStartedTrackingBy(ServerPlayerEntity player) { super.onStartedTrackingBy(player); bossBar.addPlayer(player); }

    @Override
    public void onStoppedTrackingBy(ServerPlayerEntity player) { super.onStoppedTrackingBy(player); bossBar.removePlayer(player); }

    @Override
    public void setCustomName(Text name) { super.setCustomName(name); bossBar.setName(getDisplayName()); }

    @Override
    public boolean canImmediatelyDespawn(double distance) { return false; }

    @Override
    protected void mobTick() {
        super.mobTick();
        bossBar.setPercent(getHealth() / getMaxHealth());
        if (getTarget() != null && --slamCooldown <= 0) {
            slamCooldown = getHealth() < getMaxHealth() / 2 ? 100 : 160;
            slam();
        }
        if (getHealth() < getMaxHealth() / 2 && age % 300 == 0) summon();
    }

    private void slam() {
        if (!(getWorld() instanceof ServerWorld sw)) return;
        sw.spawnParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.2, getZ(), 12, 3.0, 0.2, 3.0, 0.0);
        sw.playSound(null, getBlockPos(), SoundEvents.ENTITY_RAVAGER_ROAR, SoundCategory.HOSTILE, 2.0f, 0.6f);
        for (PlayerEntity p : sw.getEntitiesByClass(PlayerEntity.class, getBoundingBox().expand(8.0, 2.0, 8.0), x -> true)) {
            p.damage(getDamageSources().mobAttack(this), 10.0f);
            p.takeKnockback(1.2, getX() - p.getX(), getZ() - p.getZ());
            p.addStatusEffect(new StatusEffectInstance(ModEffects.SOURNESS, 100, 0));
        }
    }

    private void summon() {
        if (!(getWorld() instanceof ServerWorld sw)) return;
        for (int i = 0; i < 2; i++) {
            SilverfishEntity s = net.minecraft.entity.EntityType.SILVERFISH.create(sw);
            if (s == null) continue;
            s.refreshPositionAndAngles(getX() + random.nextInt(5) - 2, getY(), getZ() + random.nextInt(5) - 2, 0, 0);
            sw.spawnEntity(s);
        }
    }
}
