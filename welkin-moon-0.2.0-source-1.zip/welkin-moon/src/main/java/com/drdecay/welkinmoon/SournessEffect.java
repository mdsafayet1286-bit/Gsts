package com.drdecay.welkinmoon;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectCategory;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Sourness: blurry, wobbling vision (uses the nausea screen distortion). */
public class SournessEffect extends StatusEffect {
    public SournessEffect() { super(StatusEffectCategory.HARMFUL, 0xB5D336); }

    @Override
    public boolean canApplyUpdateEffect(int duration, int amplifier) { return duration % 10 == 0; }

    @Override
    public boolean applyUpdateEffect(LivingEntity entity, int amplifier) {
        if (!entity.getWorld().isClient) {
            entity.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 40, 0, false, false, false));
        }
        return true;
    }
}
