package com.drdecay.welkinmoon;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.SpiderEntityRenderer;
import net.minecraft.util.Identifier;

public class DreadSpiderRenderer extends SpiderEntityRenderer<DreadSpiderEntity> {
    private static final Identifier TEXTURE = WelkinMoon.id("textures/entity/dread_spider.png");
    public DreadSpiderRenderer(EntityRendererFactory.Context ctx) { super(ctx); }
    @Override public Identifier getTexture(DreadSpiderEntity entity) { return TEXTURE; }
}
