package com.drdecay.welkinmoon;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.entity.FlyingItemEntityRenderer;

public class WelkinMoonClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getCutout(), ModBlocks.BAMBOO_PILLAR, ModBlocks.METAL_STRING, ModBlocks.CARAMBOLA_SAPLING, ModBlocks2.DREAD_SAPLING, ModBlocks2.ASHEN_SAPLING);
        BlockRenderLayerMap.INSTANCE.putBlocks(RenderLayer.getCutoutMipped(), ModBlocks.CARAMBOLA_LEAVES, ModBlocks2.DREAD_LEAVES, ModBlocks2.ASHEN_LEAVES);
        EntityRendererRegistry.register(ModEntities.CONSTRUCTOR_ZOMBIE, ConstructorZombieRenderer::new);
        EntityRendererRegistry.register(ModEntities.RUSTED_SKELETON, RustedSkeletonRenderer::new);
        EntityRendererRegistry.register(ModEntities.DREAD_SPIDER, DreadSpiderRenderer::new);
        EntityRendererRegistry.register(ModEntities.OVERSEER, OverseerRenderer::new);
        EntityRendererRegistry.register(ModEntities.THROWN_BAG, FlyingItemEntityRenderer::new);
    }
}
