package com.drdecay.welkinmoon;

import net.minecraft.block.Block;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/** Right-click a block to place it; right-click in the air to throw it. */
public class BagOfCementItem extends BlockItem {
    public BagOfCementItem(Block block, Settings settings) { super(block, settings); }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);
        world.playSound(null, user.getX(), user.getY(), user.getZ(), SoundEvents.ENTITY_SNOWBALL_THROW, SoundCategory.PLAYERS, 0.5f, 0.6f);
        if (!world.isClient) {
            ThrownBagEntity e = new ThrownBagEntity(world, user);
            e.setItem(stack);
            e.setVelocity(user, user.getPitch(), user.getYaw(), 0.0f, 1.2f, 1.0f);
            world.spawnEntity(e);
        }
        if (!user.getAbilities().creativeMode) stack.decrement(1);
        return TypedActionResult.success(stack, world.isClient());
    }
}
