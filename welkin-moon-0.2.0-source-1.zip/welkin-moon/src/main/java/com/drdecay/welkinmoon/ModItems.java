package com.drdecay.welkinmoon;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.component.type.FoodComponent;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.Item;
import net.minecraft.item.ItemConvertible;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;

public final class ModItems {
    public static final List<ItemConvertible> ALL = new ArrayList<>();

    public static final Item TIN_INGOT = reg("tin_ingot", new Item(new Item.Settings()));
    public static final Item RAW_TIN = reg("raw_tin", new Item(new Item.Settings()));
    public static final Item BAMBOO_STICK = reg("bamboo_stick", new Item(new Item.Settings()));
    public static final Item POWDERED_CEMENT = reg("powdered_cement", new Item(new Item.Settings()));
    public static final Item CARAMBOLA = reg("carambola", new Item(new Item.Settings().food(
        new FoodComponent.Builder().nutrition(4).saturationModifier(0.3f).build())));
    // Unripe: sour. Gives Sourness for 5 seconds (100 ticks).
    public static final Item UNRIPE_CARAMBOLA = reg("unripe_carambola", new Item(new Item.Settings().food(
        new FoodComponent.Builder().nutrition(2).saturationModifier(0.1f)
            .statusEffect(new StatusEffectInstance(ModEffects.SOURNESS, 100, 0), 1.0f).build())));

    private static Item reg(String name, Item item) {
        Registry.register(Registries.ITEM, WelkinMoon.id(name), item);
        ALL.add(item);
        return item;
    }

    public static void init() {}
}
