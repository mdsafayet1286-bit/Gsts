package com.drdecay.welkinmoon;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.ModificationPhase;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.BiomeTags;
import net.minecraft.util.Identifier;
import net.minecraft.world.biome.BiomeKeys;
import net.minecraft.world.gen.GenerationStep;
import net.minecraft.world.gen.feature.PlacedFeature;

public class WelkinMoon implements ModInitializer {
    public static final String MOD_ID = "welkin_moon";

    public static Identifier id(String path) { return Identifier.of(MOD_ID, path); }

    private static RegistryKey<PlacedFeature> placed(String n) { return RegistryKey.of(RegistryKeys.PLACED_FEATURE, id(n)); }

    @Override
    public void onInitialize() {
        ModEffects.init();
        ModItems.init();
        ModBlocks.init();
        ModBlocks2.init();
        ModEntities.init();
        ModItems2.init();
        ModItemGroup.init();
        OverseerSpawner.init();

        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Feature.UNDERGROUND_ORES, placed("tin_ore"));
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Feature.UNDERGROUND_ORES, placed("cement_ore"));
        BiomeModifications.addFeature(BiomeSelectors.foundInOverworld(), GenerationStep.Feature.UNDERGROUND_ORES, placed("moonstone_ore"));
        BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_FOREST), GenerationStep.Feature.VEGETAL_DECORATION, placed("carambola_tree"));
        BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_JUNGLE), GenerationStep.Feature.VEGETAL_DECORATION, placed("carambola_tree"));
        BiomeModifications.addFeature(BiomeSelectors.tag(BiomeTags.IS_FOREST), GenerationStep.Feature.VEGETAL_DECORATION, placed("ashen_tree"));

        // Dread Forest: the Dark Forest becomes a dense, foggy forest of massive trees.
        BiomeModifications.create(id("dread_forest")).add(ModificationPhase.ADDITIONS, BiomeSelectors.includeByKey(BiomeKeys.DARK_FOREST), ctx -> {
            ctx.getGenerationSettings().addFeature(GenerationStep.Feature.VEGETAL_DECORATION, placed("dread_massive_tree"));
            ctx.getGenerationSettings().addFeature(GenerationStep.Feature.VEGETAL_DECORATION, placed("dread_tree"));
            ctx.getEffects().setFogColor(0x0b0b12);
            ctx.getEffects().setSkyColor(0x14141e);
            ctx.getEffects().setWaterColor(0x1b2a2e);
            ctx.getEffects().setWaterFogColor(0x050510);
        });
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(BiomeKeys.DARK_FOREST), SpawnGroup.MONSTER, ModEntities.DREAD_SPIDER, 80, 2, 4);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(BiomeKeys.DARK_FOREST), SpawnGroup.MONSTER, ModEntities.RUSTED_SKELETON, 60, 1, 3);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, ModEntities.RUSTED_SKELETON, 6, 1, 2);
        BiomeModifications.addSpawn(BiomeSelectors.foundInOverworld(), SpawnGroup.MONSTER, ModEntities.DREAD_SPIDER, 4, 1, 2);
    }
}
