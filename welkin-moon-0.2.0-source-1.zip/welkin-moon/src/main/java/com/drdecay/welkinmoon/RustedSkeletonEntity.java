package com.drdecay.welkinmoon;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.entity.mob.SkeletonEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.random.Random;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.World;

/** A melee skeleton variant wearing tin gear. */
public class RustedSkeletonEntity extends SkeletonEntity {
    public RustedSkeletonEntity(EntityType<? extends SkeletonEntity> type, World world) { super(type, world); }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return AbstractSkeletonEntity.createAbstractSkeletonAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 28.0).add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 4.0);
    }

    @Override
    protected void initEquipment(Random random, LocalDifficulty difficulty) {
        equipStack(EquipmentSlot.MAINHAND, new ItemStack(random.nextInt(3) == 0 ? ModItems2.SOUR_BLADE : ModItems2.TIN_SWORD));
        equipStack(EquipmentSlot.HEAD, new ItemStack(ModItems2.TIN_HELMET));
    }
}
