package com.drdecay.welkinmoon;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.RegistryWrapper;
import net.minecraft.world.PersistentState;

/** Remembers which strongholds already had their Overseer. */
public class OverseerSpawnState extends PersistentState {
    public static final PersistentState.Type<OverseerSpawnState> TYPE = new PersistentState.Type<>(OverseerSpawnState::new, OverseerSpawnState::load, null);
    public final Set<Long> spawned = new HashSet<>();

    public OverseerSpawnState() {}

    public static OverseerSpawnState load(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        OverseerSpawnState s = new OverseerSpawnState();
        for (long l : nbt.getLongArray("spawned")) s.spawned.add(l);
        return s;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt, RegistryWrapper.WrapperLookup lookup) {
        nbt.putLongArray("spawned", spawned.stream().mapToLong(Long::longValue).toArray());
        return nbt;
    }
}
