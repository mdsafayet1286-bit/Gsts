package com.drdecay.welkinmoon;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.entity.*;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.world.Heightmap;

public final class ModEntities {
    public static final EntityType<ConstructorZombieEntity> CONSTRUCTOR_ZOMBIE = reg("constructor_zombie",
        EntityType.Builder.create(ConstructorZombieEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.95f).maxTrackingRange(8));
    public static final EntityType<RustedSkeletonEntity> RUSTED_SKELETON = reg("rusted_skeleton",
        EntityType.Builder.create(RustedSkeletonEntity::new, SpawnGroup.MONSTER).dimensions(0.6f, 1.99f).maxTrackingRange(8));
    public static final EntityType<DreadSpiderEntity> DREAD_SPIDER = reg("dread_spider",
        EntityType.Builder.create(DreadSpiderEntity::new, SpawnGroup.MONSTER).dimensions(1.4f, 0.9f).maxTrackingRange(8));
    public static final EntityType<OverseerEntity> OVERSEER = reg("stronghold_overseer",
        EntityType.Builder.create(OverseerEntity::new, SpawnGroup.MONSTER).dimensions(1.2f, 3.6f).maxTrackingRange(10));
    public static final EntityType<ThrownBagEntity> THROWN_BAG = reg("thrown_bag_of_cement",
        EntityType.Builder.<ThrownBagEntity>create(ThrownBagEntity::new, SpawnGroup.MISC).dimensions(0.25f, 0.25f).maxTrackingRange(4).trackingTickInterval(10));

    private static <T extends Entity> EntityType<T> reg(String name, EntityType.Builder<T> b) {
        return Registry.register(Registries.ENTITY_TYPE, WelkinMoon.id(name), b.build(name));
    }

    public static void init() {
        FabricDefaultAttributeRegistry.register(CONSTRUCTOR_ZOMBIE, ConstructorZombieEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(RUSTED_SKELETON, RustedSkeletonEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(DREAD_SPIDER, DreadSpiderEntity.createAttributes());
        FabricDefaultAttributeRegistry.register(OVERSEER, OverseerEntity.createAttributes());
        SpawnRestriction.register(CONSTRUCTOR_ZOMBIE, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        SpawnRestriction.register(RUSTED_SKELETON, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
        SpawnRestriction.register(DREAD_SPIDER, SpawnLocationTypes.ON_GROUND, Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, HostileEntity::canSpawnInDark);
    }
}
