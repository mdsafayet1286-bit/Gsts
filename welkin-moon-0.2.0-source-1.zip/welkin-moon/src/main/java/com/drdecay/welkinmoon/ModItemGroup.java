package com.drdecay.welkinmoon;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemConvertible;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;

public final class ModItemGroup {
    public static void init() {
        Registry.register(Registries.ITEM_GROUP, WelkinMoon.id("main"), FabricItemGroup.builder()
            .icon(() -> new ItemStack(ModItems.TIN_INGOT))
            .displayName(Text.translatable("itemGroup.welkin_moon.main"))
            .entries((ctx, entries) -> { for (ItemConvertible i : ModItems.ALL) entries.add(i); })
            .build());
    }
}
