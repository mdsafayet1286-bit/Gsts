package com.drdecay.welkinmoon;

import java.util.List;
import java.util.Map;
import net.minecraft.item.*;
import net.minecraft.recipe.Ingredient;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvents;

public final class ModItems2 {
    private static final ToolMaterial TIN = TinToolMaterial.INSTANCE;

    public static final Item MOONSTONE = reg("moonstone", new Item(new Item.Settings()));
    public static final Item TIN_SWORD = reg("tin_sword", new SwordItem(TIN, new Item.Settings().attributeModifiers(SwordItem.createAttributeModifiers(TIN, 3, -2.4f))));
    public static final Item TIN_PICKAXE = reg("tin_pickaxe", new PickaxeItem(TIN, new Item.Settings().attributeModifiers(PickaxeItem.createAttributeModifiers(TIN, 1.0f, -2.8f))));
    public static final Item TIN_AXE = reg("tin_axe", new AxeItem(TIN, new Item.Settings().attributeModifiers(AxeItem.createAttributeModifiers(TIN, 6.0f, -3.1f))));
    public static final Item TIN_SHOVEL = reg("tin_shovel", new ShovelItem(TIN, new Item.Settings().attributeModifiers(ShovelItem.createAttributeModifiers(TIN, 1.5f, -3.0f))));
    public static final Item TIN_HOE = reg("tin_hoe", new HoeItem(TIN, new Item.Settings().attributeModifiers(HoeItem.createAttributeModifiers(TIN, -1.0f, -2.0f))));
    public static final Item SOUR_BLADE = reg("sour_blade", new SourBladeItem(TIN, new Item.Settings().rarity(Rarity.UNCOMMON).attributeModifiers(SwordItem.createAttributeModifiers(TIN, 4, -2.4f))));
    public static final Item CEMENT_HAMMER = reg("cement_hammer", new CementHammerItem(TIN, new Item.Settings().rarity(Rarity.UNCOMMON).attributeModifiers(AxeItem.createAttributeModifiers(TIN, 8.0f, -3.4f))));

    public static final RegistryEntry<ArmorMaterial> TIN_ARMOR = Registry.registerReference(Registries.ARMOR_MATERIAL, WelkinMoon.id("tin"),
        new ArmorMaterial(Map.of(ArmorItem.Type.BOOTS, 1, ArmorItem.Type.LEGGINGS, 4, ArmorItem.Type.CHESTPLATE, 5, ArmorItem.Type.HELMET, 2, ArmorItem.Type.BODY, 5),
            12, SoundEvents.ITEM_ARMOR_EQUIP_IRON, () -> Ingredient.ofItems(ModItems.TIN_INGOT), List.of(new ArmorMaterial.Layer(WelkinMoon.id("tin"))), 0.0f, 0.0f));
    public static final Item TIN_HELMET = reg("tin_helmet", new ArmorItem(TIN_ARMOR, ArmorItem.Type.HELMET, new Item.Settings().maxDamage(ArmorItem.Type.HELMET.getMaxDamage(12))));
    public static final Item TIN_CHESTPLATE = reg("tin_chestplate", new ArmorItem(TIN_ARMOR, ArmorItem.Type.CHESTPLATE, new Item.Settings().maxDamage(ArmorItem.Type.CHESTPLATE.getMaxDamage(12))));
    public static final Item TIN_LEGGINGS = reg("tin_leggings", new ArmorItem(TIN_ARMOR, ArmorItem.Type.LEGGINGS, new Item.Settings().maxDamage(ArmorItem.Type.LEGGINGS.getMaxDamage(12))));
    public static final Item TIN_BOOTS = reg("tin_boots", new ArmorItem(TIN_ARMOR, ArmorItem.Type.BOOTS, new Item.Settings().maxDamage(ArmorItem.Type.BOOTS.getMaxDamage(12))));

    public static final Item CONSTRUCTOR_ZOMBIE_EGG = reg("constructor_zombie_spawn_egg", new SpawnEggItem(ModEntities.CONSTRUCTOR_ZOMBIE, 0xE0A020, 0x5A7A3A, new Item.Settings()));
    public static final Item RUSTED_SKELETON_EGG = reg("rusted_skeleton_spawn_egg", new SpawnEggItem(ModEntities.RUSTED_SKELETON, 0x7D7364, 0xB5602A, new Item.Settings()));
    public static final Item DREAD_SPIDER_EGG = reg("dread_spider_spawn_egg", new SpawnEggItem(ModEntities.DREAD_SPIDER, 0x1C1226, 0xFF1428, new Item.Settings()));
    public static final Item OVERSEER_EGG = reg("stronghold_overseer_spawn_egg", new SpawnEggItem(ModEntities.OVERSEER, 0x5C6068, 0xFF2814, new Item.Settings()));

    private static Item reg(String name, Item item) {
        Registry.register(Registries.ITEM, WelkinMoon.id(name), item);
        ModItems.ALL.add(item);
        return item;
    }

    public static void init() {}
}
