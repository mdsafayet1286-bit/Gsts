package com.drdecay.welkinmoon;

import net.fabricmc.fabric.api.registry.FlammableBlockRegistry;
import net.fabricmc.fabric.api.registry.StrippableBlockRegistry;
import net.minecraft.block.*;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;
import java.util.Optional;

public final class ModBlocks {
    public static final Block TIN_ORE = reg("tin_ore", new Block(AbstractBlock.Settings.copy(Blocks.IRON_ORE)));
    public static final Block DEEPSLATE_TIN_ORE = reg("deepslate_tin_ore", new Block(AbstractBlock.Settings.copy(Blocks.DEEPSLATE_IRON_ORE)));
    public static final Block CORRUGATED_METAL_WALL = reg("corrugated_metal_wall", new Block(AbstractBlock.Settings.create().strength(3.0f, 6.0f).requiresTool().sounds(BlockSoundGroup.METAL)));
    public static final Block BAMBOO_PILLAR = reg("bamboo_pillar", new PaneBlock(AbstractBlock.Settings.create().strength(1.5f, 3.0f).sounds(BlockSoundGroup.BAMBOO).nonOpaque()));
    public static final Block METAL_STRING = reg("metal_string", new MetalStringBlock(AbstractBlock.Settings.create().noCollision().breakInstantly().sounds(BlockSoundGroup.METAL).nonOpaque()
        .luminance(s -> s.get(MetalStringBlock.HEAT) * 3).pistonBehavior(net.minecraft.block.piston.PistonBehavior.DESTROY)));
    public static final Block BAG_OF_CEMENT = reg("bag_of_cement", new BagOfCementBlock(AbstractBlock.Settings.create().strength(0.5f).sounds(BlockSoundGroup.WOOL).nonOpaque()));

    public static final Block SOLID_CEMENT = reg("solid_cement", new Block(AbstractBlock.Settings.copy(Blocks.STONE).strength(1.8f, 6.0f)));
    public static final Block CEMENT_BLOCK = reg("cement_block", new ConcretePowderBlock(SOLID_CEMENT, AbstractBlock.Settings.copy(Blocks.GRAVEL)));
    public static final Block WHITE_BRICKS = reg("white_bricks", new Block(AbstractBlock.Settings.copy(Blocks.BRICKS)));
    public static final Block WEATHERED_BRICKS = reg("weathered_bricks", new Block(AbstractBlock.Settings.copy(Blocks.BRICKS)));
    public static final Block SOLID_CEMENT_STAIRS = reg("solid_cement_stairs", new StairsBlock(SOLID_CEMENT.getDefaultState(), AbstractBlock.Settings.copy(SOLID_CEMENT)));
    public static final Block SOLID_CEMENT_SLAB = reg("solid_cement_slab", new SlabBlock(AbstractBlock.Settings.copy(SOLID_CEMENT)));
    public static final Block SOLID_CEMENT_WALL = reg("solid_cement_wall", new WallBlock(AbstractBlock.Settings.copy(SOLID_CEMENT)));
    public static final Block WHITE_BRICKS_STAIRS = reg("white_bricks_stairs", new StairsBlock(WHITE_BRICKS.getDefaultState(), AbstractBlock.Settings.copy(WHITE_BRICKS)));
    public static final Block WHITE_BRICKS_SLAB = reg("white_bricks_slab", new SlabBlock(AbstractBlock.Settings.copy(WHITE_BRICKS)));
    public static final Block WHITE_BRICKS_WALL = reg("white_bricks_wall", new WallBlock(AbstractBlock.Settings.copy(WHITE_BRICKS)));
    public static final Block WEATHERED_BRICKS_STAIRS = reg("weathered_bricks_stairs", new StairsBlock(WEATHERED_BRICKS.getDefaultState(), AbstractBlock.Settings.copy(WEATHERED_BRICKS)));
    public static final Block WEATHERED_BRICKS_SLAB = reg("weathered_bricks_slab", new SlabBlock(AbstractBlock.Settings.copy(WEATHERED_BRICKS)));
    public static final Block WEATHERED_BRICKS_WALL = reg("weathered_bricks_wall", new WallBlock(AbstractBlock.Settings.copy(WEATHERED_BRICKS)));

    public static final Block CARAMBOLA_LOG = reg("carambola_log", new PillarBlock(AbstractBlock.Settings.copy(Blocks.OAK_LOG)));
    public static final Block STRIPPED_CARAMBOLA_LOG = reg("stripped_carambola_log", new PillarBlock(AbstractBlock.Settings.copy(Blocks.STRIPPED_OAK_LOG)));
    public static final Block CARAMBOLA_WOOD = reg("carambola_wood", new PillarBlock(AbstractBlock.Settings.copy(Blocks.OAK_WOOD)));
    public static final Block STRIPPED_CARAMBOLA_WOOD = reg("stripped_carambola_wood", new PillarBlock(AbstractBlock.Settings.copy(Blocks.STRIPPED_OAK_WOOD)));
    public static final Block CARAMBOLA_PLANKS = reg("carambola_planks", new Block(AbstractBlock.Settings.copy(Blocks.OAK_PLANKS)));
    public static final Block CARAMBOLA_STAIRS = reg("carambola_stairs", new StairsBlock(CARAMBOLA_PLANKS.getDefaultState(), AbstractBlock.Settings.copy(Blocks.OAK_STAIRS)));
    public static final Block CARAMBOLA_SLAB = reg("carambola_slab", new SlabBlock(AbstractBlock.Settings.copy(Blocks.OAK_SLAB)));
    public static final Block CARAMBOLA_LEAVES = reg("carambola_leaves", new LeavesBlock(AbstractBlock.Settings.copy(Blocks.OAK_LEAVES)));
    public static final SaplingGenerator CARAMBOLA_TREE = new SaplingGenerator("carambola", Optional.empty(),
        Optional.of(RegistryKey.of(RegistryKeys.CONFIGURED_FEATURE, WelkinMoon.id("carambola_tree"))), Optional.empty());
    public static final Block CARAMBOLA_SAPLING = reg("carambola_sapling", new SaplingBlock(CARAMBOLA_TREE, AbstractBlock.Settings.copy(Blocks.OAK_SAPLING)));

    private static <T extends Block> T reg(String name, T block) {
        Registry.register(Registries.BLOCK, WelkinMoon.id(name), block);
        BlockItem item = Registry.register(Registries.ITEM, WelkinMoon.id(name), name.equals("bag_of_cement") ? new BagOfCementItem(block, new Item.Settings()) : new BlockItem(block, new Item.Settings()));
        ModItems.ALL.add(item);
        return block;
    }

    public static void init() {
        StrippableBlockRegistry.register(CARAMBOLA_LOG, STRIPPED_CARAMBOLA_LOG);
        StrippableBlockRegistry.register(CARAMBOLA_WOOD, STRIPPED_CARAMBOLA_WOOD);
        FlammableBlockRegistry f = FlammableBlockRegistry.getDefaultInstance();
        for (Block b : new Block[]{CARAMBOLA_LOG, STRIPPED_CARAMBOLA_LOG, CARAMBOLA_WOOD, STRIPPED_CARAMBOLA_WOOD}) f.add(b, 5, 5);
        for (Block b : new Block[]{CARAMBOLA_PLANKS, CARAMBOLA_STAIRS, CARAMBOLA_SLAB}) f.add(b, 5, 20);
        f.add(CARAMBOLA_LEAVES, 30, 60);
    }
}
