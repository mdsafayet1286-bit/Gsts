package com.drdecay.welkinmoon;

import net.minecraft.client.render.entity.BipedEntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.client.render.entity.model.ZombieEntityModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class OverseerRenderer extends BipedEntityRenderer<OverseerEntity, ZombieEntityModel<OverseerEntity>> {
    private static final Identifier TEXTURE = WelkinMoon.id("textures/entity/stronghold_overseer.png");

    public OverseerRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new ZombieEntityModel<>(ctx.getPart(EntityModelLayers.ZOMBIE)), 1.2f);
    }

    @Override public Identifier getTexture(OverseerEntity entity) { return TEXTURE; }

    @Override
    protected void scale(OverseerEntity entity, MatrixStack matrices, float amount) { matrices.scale(1.85f, 1.85f, 1.85f); }
}
