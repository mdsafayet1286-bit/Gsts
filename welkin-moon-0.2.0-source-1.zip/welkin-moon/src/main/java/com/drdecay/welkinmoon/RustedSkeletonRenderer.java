package com.drdecay.welkinmoon;

import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.SkeletonEntityRenderer;
import net.minecraft.entity.mob.AbstractSkeletonEntity;
import net.minecraft.util.Identifier;

public class RustedSkeletonRenderer extends SkeletonEntityRenderer {
    private static final Identifier TEXTURE = WelkinMoon.id("textures/entity/rusted_skeleton.png");
    public RustedSkeletonRenderer(EntityRendererFactory.Context ctx) { super(ctx); }
    @Override public Identifier getTexture(AbstractSkeletonEntity entity) { return TEXTURE; }
}
