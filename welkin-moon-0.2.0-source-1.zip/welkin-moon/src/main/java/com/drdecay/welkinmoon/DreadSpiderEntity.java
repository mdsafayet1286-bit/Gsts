package com.drdecay.welkinmoon;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.SpiderEntity;
import net.minecraft.world.World;

public class DreadSpiderEntity extends SpiderEntity {
    public DreadSpiderEntity(EntityType<? extends SpiderEntity> type, World world) { super(type, world); }

    public static DefaultAttributeContainer.Builder createAttributes() {
        return SpiderEntity.createSpiderAttributes().add(EntityAttributes.GENERIC_MAX_HEALTH, 24.0).add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 3.0);
    }

    @Override
    public boolean tryAttack(Entity target) {
        if (super.tryAttack(target)) {
            if (target instanceof LivingEntity l) {
                l.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 0));
                l.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 100, 0));
            }
            return true;
        }
        return false;
    }
}
