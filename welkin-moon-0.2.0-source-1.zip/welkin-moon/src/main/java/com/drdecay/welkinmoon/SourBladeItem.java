package com.drdecay.welkinmoon;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolMaterial;

public class SourBladeItem extends SwordItem {
    public SourBladeItem(ToolMaterial material, Settings settings) { super(material, settings); }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addStatusEffect(new StatusEffectInstance(ModEffects.SOURNESS, 100, 0));
        return super.postHit(stack, target, attacker);
    }
}
