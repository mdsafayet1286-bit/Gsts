package com.drdecay.welkinmoon;

import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.AxeItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ToolMaterial;

public class CementHammerItem extends AxeItem {
    public CementHammerItem(ToolMaterial material, Settings settings) { super(material, settings); }

    @Override
    public boolean postHit(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        target.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 80, 2));
        return super.postHit(stack, target, attacker);
    }
}
