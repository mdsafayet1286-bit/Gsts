package com.drdecay.welkinmoon;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.gen.structure.Structure;
import net.minecraft.world.gen.structure.StructureKeys;
import net.minecraft.structure.StructureStart;

/** Spawns the Stronghold Overseer once per stronghold when a player first walks inside it. */
public final class OverseerSpawner {
    public static void init() {
        ServerTickEvents.END_WORLD_TICK.register(world -> {
            if (world.getRegistryKey() != World.OVERWORLD || world.getTime() % 60 != 0) return;
            Structure stronghold = world.getRegistryManager().get(RegistryKeys.STRUCTURE).get(StructureKeys.STRONGHOLD);
            if (stronghold == null) return;
            OverseerSpawnState state = world.getPersistentStateManager().getOrCreate(OverseerSpawnState.TYPE, "welkin_overseer");
            for (ServerPlayerEntity p : world.getPlayers()) {
                StructureStart start = world.getStructureAccessor().getStructureAt(p.getBlockPos(), stronghold);
                if (!start.hasChildren()) continue;
                long k = start.getPos().toLong();
                if (state.spawned.contains(k)) continue;
                OverseerEntity boss = ModEntities.OVERSEER.create(world);
                if (boss == null) continue;
                Vec3d at = p.getPos().add(p.getRotationVector().multiply(7, 0, 7));
                boss.refreshPositionAndAngles(at.x, p.getY(), at.z, p.getYaw() + 180f, 0f);
                if (!world.isSpaceEmpty(boss)) boss.refreshPositionAndAngles(p.getX(), p.getY(), p.getZ(), p.getYaw() + 180f, 0f);
                boss.setPersistent();
                world.spawnEntity(boss);
                state.spawned.add(k);
                state.markDirty();
                p.sendMessage(Text.literal("The Overseer awakens...").formatted(Formatting.DARK_RED), true);
            }
        });
    }
}
