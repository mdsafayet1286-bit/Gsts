# Welkin Moon (Fabric 1.21.1) by Dr.Decay

## Build the jar
**Option A (no setup): GitHub.** Create a repo, upload this folder, open the *Actions* tab. The `build` workflow
produces `welkin-moon` artifact containing the jar (it also runs on every push).

**Option B: local.** Install JDK 21 and Gradle 8.10+, then run `gradle build`.
The jar is in `build/libs/welkin-moon-0.1.0.jar` (not the `-sources` one). Put it in `.minecraft/mods` with Fabric Loader + Fabric API.

## Included in this version (0.1.0)
Tin ore + raw tin + tin ingot, Corrugated Metal Wall, Bamboo Stick, Bamboo Pillar (iron-bar style), Metal String
(heats between two powered redstone sources, hurts, ignites, melts ice), Cement Block (gravity, hardens in water to
Solid Cement, generates underground), Powderer Cement, Bag of Cement (3D model), Solid Cement / White Bricks /
Weathered Bricks with stairs, slabs, walls, Carambola tree (log, wood, stripped, planks, stairs, slab, leaves, sapling),
Carambola (ripe) and Unripe Carambola (gives Sourness 5s), Sourness effect.

## Added in 0.2.0
Dread Forest (Dark Forest turned into a foggy forest of massive 2x2 trees; plant 2x2 Dread Saplings for massive trees),
Dread and Ashen wood sets, Moonstone ore, tin tools/armor, Sour Blade, Cement Hammer, 5 enchantments,
Constructor Zombie / Rusted Skeleton / Dread Spider, Stronghold Overseer boss (spawns once when you enter a stronghold),
Unfinished Project underground structure, throwable Bag of Cement (right-click in air), cooking on hot Metal String.
